from object import Object
from character import *
from player import *
import random


class GameBoard(Object):
    def __init__(self):
        Object.__init__(self, "桌面", "游戏进行的主要区域")

        # set plantation cards
        self.cardsHeap = \
            [CORN]*10 + [INDIGO]*12 + [CANE]*11 + \
            [TOBACCO]*9 + [COFFEE]*8
        random.shuffle(self.cardsHeap)
        # flip cards
        self.plantationCards = self.cardsHeap[0:N_PLAYERS + 1]
        self.cardsHeap = self.cardsHeap[N_PLAYERS:]

        # set pioneer ship
        self.pioneerShip = N_PLAYERS

        # set character cards
        self.characters = [
            Pioneer(0), Mayor(1), Architect(2), Supervisor(3),
            Merchant(4), Captain(5), GoldDigger(6), GoldDigger(7)
        ]

        # set players
        self.players = [
            Player(name="P1", number=1, money=3, governor=True),
            Player(name="P2", number=2, money=3, governor=False),
            Player(name="P3", number=3, money=3, governor=False),
            Player(name="P4", number=4, money=3, governor=False),
        ]
        self.players[0].buildSuburb(INDIGO)
        self.players[1].buildSuburb(INDIGO)
        self.players[2].buildSuburb(CORN)
        self.players[3].buildSuburb(CORN)
        self.turn = 0
        self.currentPlayer = self.players[self.turn]

        # start
        while True:
            self.onRound()
        pass

    def showInfo(self):
        print("翻出的种植园卡: ")
        showSuburbOption(self.plantationCards)

        print("拓荒船: ")
        print(self.pioneerShip, "个拓荒者")
        print()

        print("角色卡情况: ")
        for eachCharacter in self.characters:
            eachCharacter.showInfo()

    def flipCards(self):
        self.plantationCards = self.cardsHeap[0:5]
        self.cardsHeap = self.cardsHeap[5:]

    def oneTurn(self):
        # show information
        self.showInfo()

        # set currentPlayer
        self.currentPlayer = self.players[self.turn]

        # select character
        characters = []
        for eachCharacter in self.characters:
            if eachCharacter.enable:
                characters.append(
                    (eachCharacter.number,
                     eachCharacter.name,
                     eachCharacter.bounty)
                )

        showCharacterOption(characters)
        number = self.currentPlayer.select("角色", [row[0] for row in characters])
        self.currentPlayer.selectCharacter(self.characters[number])
        self.currentPlayer.character.selected()

        # act
        self.currentPlayer.character.act(self)

        # next turn
        self.turn = (self.turn + 1) % N_PLAYERS

    def onRound(self):
        # each player get a turn
        for i in range(N_PLAYERS):
            self.oneTurn()

        # add bounty
        for eachCharacter in self.characters:
            if eachCharacter.enable:
                eachCharacter.addBounty()
            else:
                eachCharacter.reset()
        pass
    pass
