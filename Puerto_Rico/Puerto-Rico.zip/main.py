from gameboard import *

print("波多黎各")
print()
myGameboard = GameBoard()
myGameboard.showInfo()

